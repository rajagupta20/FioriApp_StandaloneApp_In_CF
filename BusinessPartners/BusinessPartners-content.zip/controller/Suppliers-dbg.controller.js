sap.ui.define([
        "sap/ui/core/mvc/Controller",
        'sap/m/library'
	],
	/**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
	function (Controller,mobileLibrary) {
		"use strict";
        var URLHelper = mobileLibrary.URLHelper;
		return Controller.extend("ns.BusinessPartners.controller.Suppliers", {
			onInit: function () {

            },
            handleTutorial1: function (evt) {
			    URLHelper.redirect("https://developers.sap.com/group.launchpad-cf-add-custom-app.html", true);
            },
             handleTutorial2: function (evt) {
			    URLHelper.redirect("https://developers.sap.com/mission.launchpad-cf.html", true);
		    }
		});
	});
